import tkinter as tk
from twilio.rest import Client


def send_sms():
  global sender_entry, customer_entry, sms_text, status_label

  account_sid = ''
  auth_token = ''
  client = Client(account_sid, auth_token)

  sender_name = sender_entry.get().strip()
  customer_number = customer_entry.get().strip()
  sms_body = sms_text.get("1.0", tk.END).strip()

  if not sender_name or not customer_number or not sms_body:
    status_label.config(text="Please fill in all the entries!")
  else:
    try:
      message = client.messages.create(
        from_='+12059473349',
        body=f"{sender_name}   {sms_body}",
        to=customer_number
      )
      status_label.config(text="SMS sent successfully!")
      print(message.sid)
    except Exception as e:
      error_msg = str(e)
      if 'invalid "To" phone number' in error_msg:
        status_label.config(text="Please change the '0' to '+27' in the phone number")
      else:
        status_label.config(text=f"Failed to send SMS: {error_msg}")


def create_app():
  global sender_entry, customer_entry, sms_text, status_label

  root = tk.Tk()
  root.title("SMS Sender")
  root.geometry("400x300")
  root.configure(bg="light blue")

  sender_label = tk.Label(root, text="Sender's Name / Doctor's Name:")
  sender_label.pack()

  sender_entry = tk.Entry(root)
  sender_entry.pack()

  customer_label = tk.Label(root, text="Customer Phone Number:")
  customer_label.pack()

  customer_entry = tk.Entry(root)
  customer_entry.pack()

  sms_label = tk.Label(root, text="SMS Body:")
  sms_label.pack()

  sms_text = tk.Text(root, height=5)
  sms_text.pack()

  send_button = tk.Button(root, text="Send SMS", command=send_sms)
  send_button.pack()

  status_label = tk.Label(root, text="", fg="green")
  status_label.pack()

  root.mainloop()


create_app()



#message = client.messages.create(
 # from_='+12059473349',
  #body='hi its me the famous doctor lol',
 # to='+27745352163'
#)

#print(message.sid)